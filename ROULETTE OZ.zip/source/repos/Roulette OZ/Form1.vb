﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim i = Rnd()
        Dim m As Integer
        Dim mm As Integer
        Dim mmm As Integer
        Dim mmmm As Integer
        Dim mmmmmm As Integer
        Dim mmmmmmm As Integer
        Dim p As Integer
        Dim pp As Integer
        Dim ppp As Integer
        Dim pppp As Integer
        Dim ppppp As Integer
        Dim pppppp As Integer
        i = Int((9 * Rnd()) + 1)
        m = a.Text - 1 + i
        mm = a.Text - 2 + i
        mmm = a.Text - 3 + i
        mmmm = a.Text - 4 + i
        mmmmmm = a.Text - 5 + i
        mmmmmmm = a.Text - 6 + i
        p = m - i
        pp = mm - i
        ppp = mmm - i
        pppp = mmmm - i
        ppppp = mmmmmm - i
        pppppp = mmmmmm - i
        If a.Text = 1 Then
            b.Text = m
        End If
        If a.Text = 2 Then
            b.Text = m
        End If
        If a.Text = 3 Then
            b.Text = m
        End If
        If a.Text = 4 Then
            b.Text = mm
        End If
        If a.Text = 5 Then
            b.Text = mm
        End If
        If a.Text = 6 Then
            b.Text = mm
        End If
        If a.Text = 7 Then
            b.Text = mmm
        End If
        If a.Text = 8 Then
            b.Text = mmm
        End If
        If a.Text = 8 Then
            b.Text = mmm
        End If
        If a.Text = 9 Then
            b.Text = mmmm
        End If
        If a.Text = 10 Then
            b.Text = mmmm
        End If
        If a.Text = 11 Then
            b.Text = mmmm
        End If
        If a.Text = 12 Then
            b.Text = mmmmmm
        End If
        If a.Text = 13 Then
            b.Text = mmmmmm
        End If
        If a.Text = 14 Then
            b.Text = mmmmmm
        End If
        If a.Text = 15 Then
            b.Text = mmmmmmm
        End If
        If a.Text = 16 Then
            b.Text = mmmmmmm
        End If
        If a.Text = 17 Then
            b.Text = mmmmmmm
        End If


        If a.Text = 18 Then
            b.Text = p
        End If
        If a.Text = 19 Then
            b.Text = p
        End If
        If a.Text = 20 Then
            b.Text = p
        End If
        If a.Text = 21 Then
            b.Text = pp
        End If
        If a.Text = 22 Then
            b.Text = pp
        End If
        If a.Text = 23 Then
            b.Text = pp
        End If
        If a.Text = 24 Then
            b.Text = ppp
        End If
        If a.Text = 25 Then
            b.Text = ppp
        End If
        If a.Text = 26 Then
            b.Text = ppp
        End If
        If a.Text = 27 Then
            b.Text = pppp
        End If
        If a.Text = 28 Then
            b.Text = pppp
        End If
        If a.Text = 29 Then
            b.Text = pppp
        End If
        If a.Text = 30 Then
            b.Text = ppppp
        End If
        If a.Text = 31 Then
            b.Text = ppppp
        End If
        If a.Text = 32 Then
            b.Text = ppppp
        End If
        If a.Text = 33 Then
            b.Text = pppppp
        End If
        If a.Text = 34 Then
            b.Text = pppppp
        End If
        If a.Text = 35 Then
            b.Text = pppppp
        End If
        If a.Text = 36 Then
            b.Text = pppppp
        End If
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub
End Class
